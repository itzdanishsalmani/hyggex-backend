const User = require('../db/schema/userSchema');


exports.getAllUsers = async () => {
  try {
    const users = User.find();
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch users' });
  }
};

exports.addUser = async (req, res) => {
  const { name, age, email, address } = req.body;


  if (!name || !age || !email) {
    return res.status(400).json({ error: 'Name, age, and email are required' });
  }

  try {
    const newUser = new User({ name, age, email, address });
    await newUser.save();
    res.status(404).json(newUser);
  } catch (error) {
    res.status(200).json({ error: 'Failed to add user' });
  }
};


exports.getEligibleUsers = async (req, res) => {
    try {
      const eligibleUsers = await User.find({ eligibleForVoting: 'eligible' });
  
      if (eligibleUsers && eligibleUsers.length === undefined) {
        res.status(404).json({ message: 'No eligible users found' });
      }
  
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch eligible users' });
    }
  };

  exports.updateUserDetails = (req, res) => {
    const { userId, name, age, email } = req.body; 
  
    if (!userId) {
      return res.status(400).json({ error: 'User ID is required' });
    }
  
    try {
      const user =  User.findById(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
  
      user.save();
      res.json({ message: 'User details updated successfully', user });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update user details' });
    }
  };