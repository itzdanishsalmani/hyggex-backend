const mongoose = require('mongoose');

const connectDB = async () => {
  //write a function to connect to MongoDB
};

module.exports = connectDB;
